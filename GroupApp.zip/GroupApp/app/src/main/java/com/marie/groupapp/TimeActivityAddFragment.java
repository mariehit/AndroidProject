package com.marie.groupapp;

import android.app.Activity;
import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.sql.SQLException;

/**
 * Created by Marie on 4/3/2016.
 */
public class TimeActivityAddFragment extends Fragment {
    private TimeActivityDBAdapter dao;
    private AddFragmentListener addCallback;

    @Override
    public void onAttach(Activity activity) {//???
        super.onAttach(activity);

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception.
        try {
            addCallback = (AddFragmentListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement AddFragmentListener");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // If activity recreated (such as from screen rotate), restore
        // the previous article selection set by onSaveInstanceState().
        // This is primarily necessary when in the two-pane layout.
        if (savedInstanceState != null) {

        }

        // Inflate the layout for this fragment

        final View timeActivityAddView = inflater.inflate(R.layout.time_activity_add, container, false);
        Button button = (Button) timeActivityAddView.findViewById(R.id.add);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String category = ((EditText)timeActivityAddView.findViewById(R.id.catetory_add)).getText().toString();
                String title = ((EditText)timeActivityAddView.findViewById(R.id.title)).getText().toString();
                String duration = ((EditText)timeActivityAddView.findViewById(R.id.duration)).getText().toString();
                String note = ((EditText)timeActivityAddView.findViewById(R.id.note)).getText().toString();
                String date = ((EditText)timeActivityAddView.findViewById(R.id.date)).getText().toString();
                String priority = ((EditText)timeActivityAddView.findViewById(R.id.priority)).getText().toString();
                addActivity(category, title, duration, note, date, priority);
            }
        });

        return timeActivityAddView;
    }

    public void addActivity(String category, String title, String duration, String note, String creationDate, String priority) {

        new AsyncTask<String, Void, Long>() {

            @Override
            protected Long doInBackground(String... param) {
                dao = new TimeActivityDBAdapter(getActivity());
                try {
                    dao.reOpen();
                    return dao.insertRecord(param[0], param[1], param[2], param[3], param[4], param[5]);
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                return null;
            }

        }.execute(category, title, duration, note, creationDate, priority);

        addCallback.afterAdd();

    }

    interface AddFragmentListener {
        void afterAdd();
    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        // Save the current article selection in case we need to recreate the fragment
        //outState.putLong(ARG_ID, currentId);
    }

}
