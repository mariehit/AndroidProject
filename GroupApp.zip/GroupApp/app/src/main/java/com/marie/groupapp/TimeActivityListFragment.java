package com.marie.groupapp;

import android.app.Activity;
import android.database.Cursor;
import android.os.AsyncTask;
import android.support.v4.app.ListFragment; //android.app.ListFragment;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SimpleCursorAdapter;

import java.sql.SQLException;

/**
 * Created by Marie on 3/27/2016.
 */
public class TimeActivityListFragment extends ListFragment{

    private SimpleCursorAdapter dataAdapter;
    private TimeActivityDBAdapter dao;
    private ListFragmentListener listCallback;

    @Override
    public void onAttach(Activity activity) {//???
        super.onAttach(activity);

        // This makes sure that the container activity has implemented
        // the callback interface. If not, it throws an exception.
        try {
            listCallback = (ListFragmentListener) activity;
        } catch (ClassCastException e) {
            throw new ClassCastException(activity.toString()
                    + " must implement ListFragmentListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Report that this fragment would like to participate in populating the options menu
        // by receiving a call to onCreateOptionsMenu(Menu, MenuInflater) and related methods.
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        if (savedInstanceState != null) {

        }
        final View timeActivityListView = inflater.inflate(R.layout.time_activity_list_fragment, container, false);
        Button button = (Button) timeActivityListView.findViewById(R.id.add);
        button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                listCallback.onAddSelected();
            }
        });

        return timeActivityListView;
    }

    @Override
    public void onStart() {
        super.onStart();
        display();
    }
    @Override
    public void onCreateOptionsMenu (Menu menu, MenuInflater inflater) {
        inflater.inflate(R.menu.time_activity_option_menu, menu);
    }
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        //need update
        return true;
    }

    private void display() {

        String[] columns = {TimeActivityDBAdapter.KEY_TITLE};
        int[] to = new int[] {R.id.title_list};

        //???
        dataAdapter = new SimpleCursorAdapter(
                getActivity(),
                R.layout.time_activity_list_title,
                null,
                columns,
                to,
                0);

        new AsyncTask<Void, Void, Cursor>() {
            @Override
            protected Cursor doInBackground(Void... objects) {
                dao = new TimeActivityDBAdapter(getActivity());
                try {
                    dao.reOpen();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                return dao.fetchAllTitles();
            }

            @Override
            public void onPostExecute(Cursor c){
                dataAdapter.swapCursor(c);
            }
        }.execute();

        setListAdapter(dataAdapter);


    }

    @Override
    public void onListItemClick(ListView l, View v, int position, long id) {
        // Notify the parent activity of selected item

        listCallback.onActivitySelected(id);

        // Set the item as checked to be highlighted when in two-pane layout
        getListView().setItemChecked(position, true);
    }

    public interface ListFragmentListener {

        void onActivitySelected(long id);
        void onAddSelected();
    }



}
