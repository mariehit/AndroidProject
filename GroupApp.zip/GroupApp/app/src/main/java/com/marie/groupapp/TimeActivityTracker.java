package com.marie.groupapp;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.Menu;
import android.view.MenuItem;

import java.sql.SQLException;

import static android.transition.TransitionManager.go;

public class TimeActivityTracker extends AppCompatActivity implements TimeActivityListFragment.ListFragmentListener,
        TimeActivityAddFragment.AddFragmentListener {

    private TimeActivityDBAdapter dao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.time_activity_tracker);
        Toolbar myToolbar = (Toolbar) findViewById(R.id.group_toolbar);
        setSupportActionBar(myToolbar);
        //create dummy data records
        new AsyncTask<TimeActivityTracker, Void, Void>() {
            @Override
            protected Void doInBackground(TimeActivityTracker... activity) {
                dao = new TimeActivityDBAdapter(activity[0]);
                try {
                    dao.open();
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                dao.deleteAll();
                dao.insertRecords();
                return null;
            }
        }.execute(this);

        // Check whether the activity is using the layout version with
        // the FrameLayout. If so, we must add the first fragment
        if (findViewById(R.id.time_activity_fragment_container) != null) {

            // However, if we're being restored from a previous state,
            // then we don't need to do anything and should return or else
            // we could end up with overlapping fragments.
            if (savedInstanceState != null) {
                return;
            }

            // Create an instance of ExampleFragment
            TimeActivityListFragment firstFragment = new TimeActivityListFragment();

            // In case this activity was started with special instructions from an Intent,
            // pass the Intent's extras to the fragment as arguments
            firstFragment.setArguments(getIntent().getExtras());

            // Add the fragment to the 'fragment_container' FrameLayout
            getSupportFragmentManager().beginTransaction()
                    .add(R.id.time_activity_fragment_container, firstFragment).commit();
        }
    }

    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.group_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml. ???
        int id = item.getItemId();

        switch (id){
            case R.id.expense_tracker:
                go(ExpenseTracker_MainActivity.class);
                break;
            case R.id.time_activity:
                //this activity
                break;
            case R.id.action_three:
                go(CarbonFootprintCalculator.class);
                break;
            case R.id.contacts_list:
                go(ContactsList.class);
                break;
        }

        return super.onOptionsItemSelected(item);
    }

    private void go(Class c){
        Intent intent = new Intent(this, c);
        startActivity(intent);
    }

    @Override
    public void onActivitySelected(long id) {
        // one-pane layout and must swap frags...

        // Create fragment and give it an argument for the selected article
        TimeActivityDetailFragment newFragment = new TimeActivityDetailFragment();
        Bundle args = new Bundle();
        args.putLong(TimeActivityDetailFragment.ARG_ID, id);
        newFragment.setArguments(args);
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.time_activity_fragment_container, newFragment);
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();
    }

    @Override
    public void onAddSelected() {
        TimeActivityAddFragment newFragment = new TimeActivityAddFragment();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.time_activity_fragment_container, newFragment);
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();
    }

    @Override
    public void afterAdd() {
        TimeActivityListFragment newFragment = new TimeActivityListFragment();
        FragmentTransaction transaction = getSupportFragmentManager().beginTransaction();

        // Replace whatever is in the fragment_container view with this fragment,
        // and add the transaction to the back stack so the user can navigate back
        transaction.replace(R.id.time_activity_fragment_container, newFragment);
        transaction.addToBackStack(null);

        // Commit the transaction
        transaction.commit();
    }
}
