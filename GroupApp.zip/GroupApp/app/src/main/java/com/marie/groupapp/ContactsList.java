package com.marie.groupapp;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;

/**
 * Created by Marie on 4/3/2016.
 */
public class ContactsList extends AppCompatActivity{
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.contacts_list);
    }
}
