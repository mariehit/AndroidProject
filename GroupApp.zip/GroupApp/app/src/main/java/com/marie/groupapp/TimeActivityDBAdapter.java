package com.marie.groupapp;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import java.sql.SQLException;

/**
 * Created by Marie on 4/2/2016.
 */
public class TimeActivityDBAdapter {
    //column name public
    public static final String KEY_ID = "_id";
    public static final String KEY_CATEGORY = "category";
    public static final String KEY_TITLE = "tigle";
    public static final String KEY_DURATION = "duration";
    public static final String KEY_NOTE = "note";
    public static final String KEY_CREATION_DATE = "creation_date";
    public static final String KEY_PRIORITY = "priority";

    //other constant
    private static final String DB_NAME = "TimeActivityDB";
    private static final int DB_VERSION = 1;
    private static final String SQLITE_TABLE = "Activity";

    private static final String TABLE_CREATE = "CREATE TABLE if not exists " + SQLITE_TABLE + " (" +
            KEY_ID + " integer PRIMARY KEY autoincrement," +
            KEY_CATEGORY + "," +
            KEY_TITLE + "," +
            KEY_DURATION + "," +
            KEY_NOTE + "," +
            KEY_CREATION_DATE + "," +
            KEY_PRIORITY + ");";

    //program variable
    private DatabaseHelper dbHelper;
    private SQLiteDatabase dB;

    private static class DatabaseHelper extends SQLiteOpenHelper {
        // Associate a DB with an Activity
        // set DB name, version;
        public DatabaseHelper(Context context) {
            super(context, DB_NAME, null, DB_VERSION);
        }

        // execute create table

        @Override
        public void onCreate(SQLiteDatabase sqLiteDatabase) {
            sqLiteDatabase.execSQL(TABLE_CREATE);
        }

        @Override
        public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
            sqLiteDatabase.execSQL("DROP TABLE IF EXISTS " + SQLITE_TABLE);
            onCreate(sqLiteDatabase);
        }
    }

    //Constructor to pass the context information
    public TimeActivityDBAdapter(Context context) {
        dbHelper = new DatabaseHelper(context);
    }


    public TimeActivityDBAdapter open() throws SQLException {
        dB = dbHelper.getWritableDatabase();//call onCreate
        return this;
    }

    public void reOpen() throws SQLException{
        dB = dbHelper.getReadableDatabase();
    }

    public void close() {
        if (dbHelper != null) dbHelper.close();
    }

    //insert data to table
    public long insertRecord(String category, String title, String duration, String note, String creationDate, String priority) {
        ContentValues record = new ContentValues();
        record.put(KEY_CATEGORY, category);
        record.put(KEY_TITLE, title);
        record.put(KEY_DURATION, duration);
        record.put(KEY_NOTE, note);
        record.put(KEY_CREATION_DATE, creationDate);
        record.put(KEY_PRIORITY, priority);
        Log.d("marie", "ladydebugger: ");
        return dB.insertOrThrow(SQLITE_TABLE, null, record);
    }

    public void insertRecords() {
        insertRecord("work", "debug", "1", "note", "2016-04-01", "high");
        insertRecord("family", "birthday", "2", "note", "2016-06-08", "high");
        insertRecord("study", "assignment", "2", "note", "2016-04-02", "medium");
    }

    //query all headlines
    public Cursor fetchAllTitles() {
        Cursor cursor = dB.query(SQLITE_TABLE, new String[] {KEY_ID, KEY_TITLE}, null, null, null, null, null);
        if(cursor != null) cursor.moveToFirst();
        return cursor;
    }

    public Cursor fetchActivityById(String id) throws SQLException {

        Cursor cursor = (id == null || id.length() == 0) ?
                dB.query(SQLITE_TABLE, new String[] {KEY_ID,KEY_CATEGORY, KEY_TITLE, KEY_DURATION,
                                KEY_NOTE, KEY_CREATION_DATE, KEY_PRIORITY},
                        null, null, null, null, null):
                dB.query(true, SQLITE_TABLE, new String[] {KEY_ID,KEY_CATEGORY, KEY_TITLE, KEY_DURATION,
                        KEY_NOTE, KEY_CREATION_DATE, KEY_PRIORITY}, KEY_ID + "= '" + id + "'", null, null, null, null, null);
        if(cursor != null) cursor.moveToFirst();
        return cursor;
    }

    public void deleteAll() {
        dB.delete(SQLITE_TABLE, null, null);
    }

}
