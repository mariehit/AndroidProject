package com.marie.groupapp;


import android.database.Cursor;
import android.os.AsyncTask;
import android.os.Bundle;
import android.support.v4.app.Fragment;//???
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import java.sql.SQLException;

/**
 * Created by Marie on 4/2/2016.
 */
public class TimeActivityDetailFragment extends Fragment {
    final static String ARG_ID = "id";
    private long currentId = -1;

    TimeActivityDBAdapter dao = null;



    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        // If activity recreated (such as from screen rotate), restore
        // the previous article selection set by onSaveInstanceState().
        // This is primarily necessary when in the two-pane layout.
        if (savedInstanceState != null) {
            currentId = savedInstanceState.getLong(ARG_ID);
        }

        // Inflate the layout for this fragment
        return inflater.inflate(R.layout.time_activity_detail, container, false);
    }

    @Override
    public void onStart() {
        super.onStart();

        Bundle args = getArguments();
        if (currentId != -1) {
            // Set article based on saved instance state defined during onCreateView
            updateActivityView(currentId);
        }else if (args != null) {
            // Set article based on argument passed in
            updateActivityView(args.getLong(ARG_ID));
            currentId = args.getLong(ARG_ID);
        }
    }

    public void updateActivityView(long id) {

        new AsyncTask<Long, Void, Cursor>() {

            @Override
            protected Cursor doInBackground(Long... id) {
                dao = new TimeActivityDBAdapter(getActivity());
                try {
                    dao.reOpen();
                    return dao.fetchActivityById(String.valueOf(id[0]));
                } catch (SQLException e) {
                    e.printStackTrace();
                }
                return null;
            }

            @Override
            public void onPostExecute(Cursor cursor) {
                String category = cursor.getString(cursor.getColumnIndexOrThrow(TimeActivityDBAdapter.KEY_CATEGORY));
                String title = cursor.getString(cursor.getColumnIndexOrThrow(TimeActivityDBAdapter.KEY_TITLE));
                String duration = cursor.getString(cursor.getColumnIndexOrThrow(TimeActivityDBAdapter.KEY_DURATION));
                String note = cursor.getString(cursor.getColumnIndexOrThrow(TimeActivityDBAdapter.KEY_NOTE));
                String date = cursor.getString(cursor.getColumnIndexOrThrow(TimeActivityDBAdapter.KEY_CREATION_DATE));
                String priority = cursor.getString(cursor.getColumnIndexOrThrow(TimeActivityDBAdapter.KEY_PRIORITY));
                TextView categoryView = (TextView) getActivity().findViewById(R.id.catetory);
                TextView titleView = (TextView) getActivity().findViewById(R.id.title);
                TextView durationView = (TextView) getActivity().findViewById(R.id.duration);
                TextView noteView = (TextView) getActivity().findViewById(R.id.note);
                TextView dateView = (TextView) getActivity().findViewById(R.id.date);
                TextView priorityView = (TextView) getActivity().findViewById(R.id.priority);
                categoryView.setText(category);
                titleView.setText(title);
                durationView.setText(duration);
                noteView.setText(note);
                dateView.setText(date);
                priorityView.setText(priority);
            }
        }.execute(id);

    }

    @Override
    public void onSaveInstanceState(Bundle outState) {
        super.onSaveInstanceState(outState);

        // Save the current article selection in case we need to recreate the fragment
        outState.putLong(ARG_ID, currentId);
    }

}
